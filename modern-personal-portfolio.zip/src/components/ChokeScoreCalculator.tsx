import React, { useState } from 'react';
import { Truck, CheckCircle, AlertOctagon, HelpCircle, Code2 } from 'lucide-react';

export default function ChokeScoreCalculator() {
  const [dwellTimeHours, setDwellTimeHours] = useState<number>(36); // e.g. 12 to 72 hrs
  const [pendingShipments, setPendingShipments] = useState<number>(1450); // 100 to 5000
  const [throughputVolume, setThroughputVolume] = useState<number>(3200); // 500 to 10000
  const [exitFailurePct, setExitFailurePct] = useState<number>(14); // 0 to 30%
  const [showSql, setShowSql] = useState<boolean>(false);

  // Normalized scoring factors (0 - 100)
  const normDwell = Math.min(100, (dwellTimeHours / 48) * 100);
  const normPending = Math.min(100, (pendingShipments / 3000) * 100);
  const normVolume = Math.min(100, (throughputVolume / 8000) * 100);
  const normExitFail = Math.min(100, (exitFailurePct / 20) * 100);

  // Sarthak's formula:
  // 35% Dwell Time + 35% Pending Shipments + 20% Volume + 10% Exit Failure Rate
  const chokeScore = Math.round(
    normDwell * 0.35 +
    normPending * 0.35 +
    normVolume * 0.20 +
    normExitFail * 0.10
  );

  const isChoked = chokeScore >= 60;

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 lg:p-8 backdrop-blur-xl shadow-2xl">
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-slate-800 gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-cyan-400 mb-1">
            <Truck className="w-4 h-4" />
            <span>Interactive Logistics Analytics Mini-Tool</span>
          </div>
          <h3 className="text-xl font-bold text-white">Warehouse Choke Score Engine</h3>
          <p className="text-sm text-slate-400">
            DuckDB SQL pipeline model calculating automated facility congestion triage.
          </p>
        </div>
        <button
          onClick={() => setShowSql(!showSql)}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 hover:text-white text-xs border border-slate-700 transition-colors"
        >
          <Code2 className="w-3.5 h-3.5 text-cyan-400" />
          <span>{showSql ? 'Hide SQL Logic' : 'View DuckDB Window Query'}</span>
        </button>
      </div>

      {showSql && (
        <div className="my-5 rounded-xl border border-slate-800 bg-slate-950 p-4 font-mono text-xs text-cyan-300/90 overflow-x-auto leading-relaxed">
          <div className="text-slate-500 mb-2">// Reconstructing journey timestamps & dwell time with DuckDB LEAD()</div>
{`WITH EnrichedShipments AS (
    SELECT 
        shipment_id,
        facility_id,
        event_time,
        LEAD(event_time) OVER (
            PARTITION BY shipment_id 
            ORDER BY event_time ASC
        ) AS next_hub_time,
        status_code
    FROM flattened_telemetry_events
)
SELECT 
    facility_id,
    AVG(DATE_DIFF('hour', event_time, next_hub_time)) AS avg_dwell_hours,
    COUNT(CASE WHEN next_hub_time IS NULL THEN 1 END) AS pending_shipments,
    ROUND((AVG(dwell_hours)*0.35 + AVG(pending)*0.35 + (COUNT(*)*0.20) + (exit_fail*0.10)), 1) AS choke_score
FROM EnrichedShipments
GROUP BY facility_id
HAVING choke_score >= 60;`}
        </div>
      )}

      {/* Sliders Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 my-6 p-5 rounded-xl bg-slate-950/70 border border-slate-800/80">
        <div>
          <div className="flex justify-between text-xs font-medium text-slate-300 mb-1.5">
            <span>Average Dwell Time (Weight: 35%)</span>
            <span className="font-mono text-cyan-400 font-semibold">{dwellTimeHours} hrs</span>
          </div>
          <input
            type="range"
            min="6"
            max="72"
            value={dwellTimeHours}
            onChange={(e) => setDwellTimeHours(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
          />
        </div>

        <div>
          <div className="flex justify-between text-xs font-medium text-slate-300 mb-1.5">
            <span>Pending Unresolved Shipments (Weight: 35%)</span>
            <span className="font-mono text-cyan-400 font-semibold">{pendingShipments.toLocaleString()} pkgs</span>
          </div>
          <input
            type="range"
            min="100"
            max="4000"
            step="50"
            value={pendingShipments}
            onChange={(e) => setPendingShipments(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
          />
        </div>

        <div>
          <div className="flex justify-between text-xs font-medium text-slate-300 mb-1.5">
            <span>Total Hub Volume (Weight: 20%)</span>
            <span className="font-mono text-cyan-400 font-semibold">{throughputVolume.toLocaleString()} txns</span>
          </div>
          <input
            type="range"
            min="500"
            max="8000"
            step="100"
            value={throughputVolume}
            onChange={(e) => setThroughputVolume(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
          />
        </div>

        <div>
          <div className="flex justify-between text-xs font-medium text-slate-300 mb-1.5">
            <span>Dispatch Failure Rate (Weight: 10%)</span>
            <span className="font-mono text-cyan-400 font-semibold">{exitFailurePct}%</span>
          </div>
          <input
            type="range"
            min="1"
            max="25"
            value={exitFailurePct}
            onChange={(e) => setExitFailurePct(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
          />
        </div>
      </div>

      {/* Real-Time Result Card */}
      <div className={`p-5 rounded-xl border flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all ${
        isChoked 
          ? 'bg-rose-950/30 border-rose-500/40' 
          : 'bg-emerald-950/20 border-emerald-500/30'
      }`}>
        <div className="flex items-center gap-4">
          <div className={`w-14 h-14 rounded-xl flex items-center justify-center font-mono font-bold text-2xl border ${
            isChoked 
              ? 'bg-rose-500/20 text-rose-300 border-rose-500/30' 
              : 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30'
          }`}>
            {chokeScore}
          </div>
          <div>
            <div className="text-xs uppercase tracking-wider font-semibold text-slate-400">
              Calculated Weighted Score (Threshold ≥ 60)
            </div>
            <div className="text-lg font-bold text-white flex items-center gap-2 mt-0.5">
              {isChoked ? (
                <>
                  <AlertOctagon className="w-5 h-5 text-rose-400" />
                  <span className="text-rose-400">PRIORITIZE FOR CLEARING (CRITICAL CONGESTION)</span>
                </>
              ) : (
                <>
                  <CheckCircle className="w-5 h-5 text-emerald-400" />
                  <span className="text-emerald-400">NORMAL FLOW (STEADY THROUGHPUT)</span>
                </>
              )}
            </div>
          </div>
        </div>

        <div className="text-xs text-slate-400 max-w-xs">
          {isChoked
            ? "Automated alert triggered: Re-route incoming long-haul freight to alternate regional transshipment hubs."
            : "Telemetry metrics within optimal operational tolerances. No intervention required."}
        </div>
      </div>
    </div>
  );
}
