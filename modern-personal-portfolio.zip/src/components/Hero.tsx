import React from 'react';
import { 
  ArrowRight, 
  TrendingUp, 
  ShieldCheck, 
  FileText, 
  Linkedin, 
  Sparkles, 
  CheckCircle2, 
  Database,
  Bot
} from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

interface HeroProps {
  onOpenResume: (tab?: 'data-analyst' | 'ai-ml') => void;
}

export default function Hero({ onOpenResume }: HeroProps) {
  return (
    <section className="relative pt-12 pb-16 lg:pt-20 lg:pb-24 overflow-hidden border-b border-slate-800/80">
      {/* Ambient background glow */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-emerald-500/10 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute top-1/3 right-10 w-[300px] h-[250px] bg-cyan-500/10 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="max-w-3xl">
          {/* Eyebrow badge */}
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-900 border border-slate-800 shadow-inner mb-6">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-300">
              Verified Candidate Portfolio • 2025 Graduating Engineer
            </span>
          </div>

          {/* Main Title */}
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.1] mb-6">
            Hi, I'm <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400">{PERSONAL_INFO.name}</span>.
            <br />
            <span className="text-slate-200 text-3xl sm:text-4xl lg:text-5xl block mt-2 font-bold">
              Uncovering hidden revenue in data &amp; engineering resilient AI.
            </span>
          </h1>

          {/* Subtitle / Positioning Statement */}
          <p className="text-base sm:text-lg text-slate-300 leading-relaxed mb-8 max-w-2xl">
            Passionate Data Analyst &amp; Applied AI/ML Developer. I bridge rigorous data analytics 
            (<span className="text-emerald-400 font-medium">SQL, Python, Power BI</span>) with applied machine learning 
            to solve measurable business problems — from recovering <strong className="text-white font-semibold">₹1.3M+ in failed transaction leakage</strong> to engineering <strong className="text-white font-semibold">zero-downtime LLM fallback pipelines</strong>.
          </p>

          {/* Primary Action Buttons */}
          <div className="flex flex-wrap items-center gap-3.5 mb-10">
            <a
              href="#case-studies"
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-sm font-bold shadow-lg shadow-emerald-500/25 transition-all transform hover:-translate-y-0.5 cursor-pointer"
            >
              <span>Explore Flagship Projects</span>
              <ArrowRight className="w-4 h-4" />
            </a>

            <button
              onClick={() => onOpenResume('data-analyst')}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-semibold border border-slate-700 hover:border-slate-600 transition-all cursor-pointer"
            >
              <FileText className="w-4 h-4 text-emerald-400" />
              <span>Review Resume &amp; Credentials</span>
            </button>

            <a
              href={PERSONAL_INFO.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-3 rounded-xl bg-slate-900/60 hover:bg-slate-800 text-slate-300 hover:text-white text-sm font-medium border border-slate-800 transition-colors"
            >
              <Linkedin className="w-4 h-4 text-cyan-400" />
              <span>LinkedIn</span>
            </a>
          </div>

          {/* Quick core competency chips */}
          <div className="flex items-center gap-2 flex-wrap text-xs text-slate-400">
            <span className="text-slate-500 uppercase tracking-wider text-[11px] font-semibold mr-1">Primary Tools:</span>
            {["Python (Pandas)", "SQL (Window Functions)", "Power BI", "DuckDB", "LLMs & Fallback Architecture", "Scikit-learn"].map((t) => (
              <span key={t} className="px-2.5 py-1 rounded-md bg-slate-900/80 border border-slate-800/80 text-slate-300 font-mono text-[11px]">
                {t}
              </span>
            ))}
          </div>
        </div>

        {/* 4 Instant Proof Metric Cards (Recruiter Scanning Matrix) */}
        <div className="mt-14 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {PERSONAL_INFO.keyMetrics.map((item, index) => (
            <div
              key={index}
              className={`p-5 rounded-2xl border transition-all duration-300 hover:-translate-y-1 ${
                item.highlight
                  ? 'bg-gradient-to-b from-emerald-950/40 to-slate-900/90 border-emerald-500/40 shadow-lg shadow-emerald-500/10'
                  : 'bg-slate-900/70 border-slate-800/80 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  {item.label}
                </span>
                {item.highlight ? (
                  <TrendingUp className="w-4 h-4 text-emerald-400" />
                ) : index === 1 ? (
                  <Database className="w-4 h-4 text-cyan-400" />
                ) : index === 2 ? (
                  <ShieldCheck className="w-4 h-4 text-amber-400" />
                ) : (
                  <Bot className="w-4 h-4 text-purple-400" />
                )}
              </div>
              <div className={`text-3xl font-extrabold font-mono tracking-tight mb-1.5 ${
                item.highlight ? 'text-emerald-400' : 'text-white'
              }`}>
                {item.value}
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                {item.sub}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
