import React, { useState } from 'react';
import { IndianRupee, AlertTriangle, TrendingUp, ShieldCheck, CheckCircle2, Sliders, RefreshCw } from 'lucide-react';

export default function PaymentLeakageSimulator() {
  const [volume, setVolume] = useState<number>(30000);
  const [failureRate, setFailureRate] = useState<number>(5.01);
  const [selectedSegment, setSelectedSegment] = useState<'all' | 'critical' | 'high' | 'monitor'>('critical');

  // Realistic calculation based on Sarthak's 30,000 transactions study
  const avgTransactionAmount = 866; // average transaction value in INR
  const totalFailed = Math.round(volume * (failureRate / 100));
  const estimatedLeakage = Math.round(totalFailed * avgTransactionAmount);
  // Based on 242 segments: ~30% of failed transactions are recoverable through smart retry & routing
  const recoverableRatio = 0.3005;
  const recoverableAmount = Math.round(estimatedLeakage * recoverableRatio);

  const sampleSegments = [
    {
      id: "SEG-089",
      gateway: "UPI Gateway 02",
      error: "Timeout_During_Auth",
      failureRate: "12.4%",
      failedCount: 412,
      recoverable: "₹3,56,792",
      triage: "critical",
      remediation: "Implement dynamic gateway failover after 2.5s timeout threshold."
    },
    {
      id: "SEG-142",
      gateway: "Card Aggregator Prime",
      error: "3DS_OTP_Delay",
      failureRate: "9.8%",
      failedCount: 388,
      recoverable: "₹3,36,008",
      triage: "critical",
      remediation: "Switch fallback SMS provider & enable in-app biometric 3DS verification."
    },
    {
      id: "SEG-017",
      gateway: "NetBanking Tier-1",
      error: "Session_Drop_Post_Redirect",
      failureRate: "8.1%",
      failedCount: 310,
      recoverable: "₹2,68,460",
      triage: "critical",
      remediation: "Webhook reconciliation and automated 1-click cart recovery link."
    },
    {
      id: "SEG-055",
      gateway: "UPI Gateway 01",
      error: "VPA_Validation_Lag",
      failureRate: "4.6%",
      failedCount: 220,
      recoverable: "₹1,90,520",
      triage: "high",
      remediation: "Pre-validate UPI handles on client input before hitting bank gateway."
    },
    {
      id: "SEG-211",
      gateway: "Wallet Route Beta",
      error: "Balance_Check_Failure",
      failureRate: "3.2%",
      failedCount: 165,
      recoverable: "₹1,42,890",
      triage: "high",
      remediation: "Prompt instant split-payment fallback if wallet balance is partial."
    }
  ];

  const filteredSegments = selectedSegment === 'all' 
    ? sampleSegments 
    : sampleSegments.filter(s => s.triage === selectedSegment);

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 lg:p-8 backdrop-blur-xl shadow-2xl">
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-slate-800 gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-1">
            <TrendingUp className="w-4 h-4" />
            <span>Interactive Analytics Lab &amp; ROI Simulator</span>
          </div>
          <h3 className="text-xl font-bold text-white">Payment Failure Recovery Engine</h3>
          <p className="text-sm text-slate-400">
            Simulate the exact statistical model Sarthak used to uncover ₹1.3M+ in recoverable leakage.
          </p>
        </div>
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-mono">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>Verified Findings: ₹1,301,381 Recoverable</span>
        </div>
      </div>

      {/* Sliders & Parameters */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-6 p-5 rounded-xl bg-slate-950/70 border border-slate-800/80">
        <div>
          <div className="flex justify-between text-xs font-medium text-slate-300 mb-2">
            <span className="flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-cyan-400" />
              Total Transaction Volume
            </span>
            <span className="font-mono text-emerald-400 font-semibold">{volume.toLocaleString()} txns</span>
          </div>
          <input
            type="range"
            min="10000"
            max="100000"
            step="5000"
            value={volume}
            onChange={(e) => setVolume(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-400"
          />
          <div className="flex justify-between text-[10px] text-slate-500 mt-1">
            <span>10k</span>
            <span>30k (Baseline)</span>
            <span>100k</span>
          </div>
        </div>

        <div>
          <div className="flex justify-between text-xs font-medium text-slate-300 mb-2">
            <span className="flex items-center gap-1.5">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
              Observed Failure Rate
            </span>
            <span className="font-mono text-amber-400 font-semibold">{failureRate}%</span>
          </div>
          <input
            type="range"
            min="2.0"
            max="10.0"
            step="0.1"
            value={failureRate}
            onChange={(e) => setFailureRate(Number(e.target.value))}
            className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-amber-400"
          />
          <div className="flex justify-between text-[10px] text-slate-500 mt-1">
            <span>2.0%</span>
            <span>5.01% (Sarthak's Analysis)</span>
            <span>10.0%</span>
          </div>
        </div>
      </div>

      {/* Calculated KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800">
          <div className="text-xs text-slate-400 mb-1">Total Failed Transactions</div>
          <div className="text-2xl font-bold font-mono text-slate-100">
            {totalFailed.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-1">
            <span>{failureRate}% of total volume</span>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800">
          <div className="text-xs text-slate-400 mb-1">Gross Revenue at Risk</div>
          <div className="text-2xl font-bold font-mono text-amber-400 flex items-center">
            <span>₹{estimatedLeakage.toLocaleString()}</span>
          </div>
          <div className="text-[11px] text-slate-500 mt-1">Across 242 failure combinations</div>
        </div>

        <div className="p-4 rounded-xl bg-emerald-950/30 border border-emerald-500/30 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 rounded-full blur-xl pointer-events-none"></div>
          <div className="text-xs text-emerald-400 font-medium mb-1">Identified Recoverable Revenue</div>
          <div className="text-2xl font-bold font-mono text-emerald-400 flex items-center">
            <span>₹{recoverableAmount.toLocaleString()}</span>
          </div>
          <div className="text-[11px] text-emerald-500/80 mt-1 flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 inline text-emerald-400" />
            <span>Via 3 Critical &amp; 16 High Segments</span>
          </div>
        </div>
      </div>

      {/* Segmentation Triage Table */}
      <div className="mt-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3">
          <h4 className="text-sm font-semibold text-slate-200">
            Segment Prioritization Matrix (Sample of 242 Segments)
          </h4>
          <div className="flex items-center gap-1.5 p-1 bg-slate-950 rounded-lg border border-slate-800 text-xs">
            <button
              onClick={() => setSelectedSegment('critical')}
              className={`px-2.5 py-1 rounded font-medium transition-all ${
                selectedSegment === 'critical'
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Critical (3)
            </button>
            <button
              onClick={() => setSelectedSegment('high')}
              className={`px-2.5 py-1 rounded font-medium transition-all ${
                selectedSegment === 'high'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              High Priority (16)
            </button>
            <button
              onClick={() => setSelectedSegment('all')}
              className={`px-2.5 py-1 rounded font-medium transition-all ${
                selectedSegment === 'all'
                  ? 'bg-slate-800 text-white'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              View All
            </button>
          </div>
        </div>

        <div className="overflow-x-auto rounded-xl border border-slate-800">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950/80 text-slate-400 border-b border-slate-800 font-mono">
              <tr>
                <th className="py-2.5 px-3">Segment ID</th>
                <th className="py-2.5 px-3">Gateway &amp; Error Signature</th>
                <th className="py-2.5 px-3">Fail Rate</th>
                <th className="py-2.5 px-3">Recoverable Value</th>
                <th className="py-2.5 px-3">Recommended Triage Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/70">
              {filteredSegments.map((seg) => (
                <tr key={seg.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="py-3 px-3 font-mono font-semibold text-slate-300">
                    {seg.id}
                  </td>
                  <td className="py-3 px-3">
                    <div className="font-medium text-slate-200">{seg.gateway}</div>
                    <div className="text-[11px] font-mono text-slate-400">{seg.error}</div>
                  </td>
                  <td className="py-3 px-3 font-mono">
                    <span className="px-2 py-0.5 rounded bg-rose-500/10 text-rose-300 border border-rose-500/20">
                      {seg.failureRate}
                    </span>
                  </td>
                  <td className="py-3 px-3 font-mono font-semibold text-emerald-400">
                    {seg.recoverable}
                  </td>
                  <td className="py-3 px-3 text-slate-300 max-w-xs">
                    {seg.remediation}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="mt-4 p-3 rounded-lg bg-slate-950/60 border border-slate-800/60 text-xs text-slate-400 flex items-center justify-between">
        <span className="flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>
            <strong>Analytical Takeaway:</strong> Rather than boiling the ocean across all 242 segments, fixing just 3 gateway timeout &amp; OTP routing issues recovers <strong>73.6%</strong> of the lost revenue.
          </span>
        </span>
        <button
          onClick={() => { setVolume(30000); setFailureRate(5.01); setSelectedSegment('critical'); }}
          className="text-slate-400 hover:text-emerald-400 text-[11px] flex items-center gap-1 ml-3 shrink-0"
        >
          <RefreshCw className="w-3 h-3" />
          <span>Reset to Original Study</span>
        </button>
      </div>
    </div>
  );
}
