import React, { useState } from 'react';
import { X, Download, FileText, CheckCircle2, ExternalLink, GraduationCap, Award } from 'lucide-react';

interface ResumeModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'data-analyst' | 'ai-ml' | 'transcript';
}

export default function ResumeModal({ isOpen, onClose, initialTab = 'data-analyst' }: ResumeModalProps) {
  const [activeTab, setActiveTab] = useState<'data-analyst' | 'ai-ml' | 'transcript'>(initialTab);

  if (!isOpen) return null;

  const pdfMap = {
    'data-analyst': {
      title: "Sarthak Baliyan — Data Analyst Resume",
      path: "/assets/aistudio/Sarthak_Baliyan_Data_Analyst_Resume_6ee55305.pdf",
      filename: "Sarthak_Baliyan_Data_Analyst_Resume.pdf",
      highlights: [
        "Full analytics lifecycle: Data Cleaning, EDA, SQL Window Functions, Power BI",
        "Payment Leakage Prioritization: ₹13L+ recoverable revenue uncovered",
        "Superstore Performance & Choked Hub logistics analytics",
        "Targeting: Data Analyst, Business Analyst, BI & Reporting roles"
      ]
    },
    'ai-ml': {
      title: "Sarthak Baliyan — AI/ML Engineer Resume",
      path: "/assets/aistudio/Sarthak_Baliyan_AI-ML_Resume_0c418cb9.pdf",
      filename: "Sarthak_Baliyan_AI_ML_Resume.pdf",
      highlights: [
        "Computer vision (YOLO), NLP, LLMs, and prompt-driven fallback systems",
        "TalentScout: AI hiring assistant with deterministic fallback engine",
        "IBM SkillsBuild ML Internship: TrafficVision AI (+30% accuracy)",
        "Targeting: Junior AI/ML Engineer, Applied AI, ML Intern roles"
      ]
    },
    'transcript': {
      title: "Official Academic Transcript — UPES Dehradun",
      path: "/assets/aistudio/TRANSCRIPT_a584bad5.pdf",
      filename: "Sarthak_Baliyan_Academic_Transcript_UPES.pdf",
      highlights: [
        "University of Petroleum and Energy Studies (UPES), Dehradun",
        "B.Tech Computer Science Engineering (Artificial Intelligence & Machine Learning)",
        "Graduating Batch 2021 – 2025 | Cumulative CGPA: 7.33 / 10 (73.3%) | Sem 8 SGPA: 7.89",
        "Verified coursework in Database Systems, Machine Learning & Cloud Architectures"
      ]
    }
  };

  const currentDoc = pdfMap[activeTab];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-4xl h-[92vh] bg-slate-900 border border-slate-700/80 rounded-2xl shadow-2xl flex flex-col overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white leading-tight">
                Verified Credentials &amp; Resume Portal
              </h3>
              <p className="text-xs text-slate-400">
                Sarthak Baliyan • Official Documents &amp; Curated Profiles
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={currentDoc.path}
              download={currentDoc.filename}
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-emerald-500 text-slate-950 text-xs font-semibold hover:bg-emerald-400 transition-colors shadow-sm"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download PDF</span>
            </a>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Bar */}
        <div className="flex items-center gap-2 px-6 py-2.5 bg-slate-900/90 border-b border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('data-analyst')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg font-medium transition-all ${
              activeTab === 'data-analyst'
                ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <FileText className="w-3.5 h-3.5 text-emerald-400" />
            <span>Data Analyst Resume</span>
          </button>

          <button
            onClick={() => setActiveTab('ai-ml')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg font-medium transition-all ${
              activeTab === 'ai-ml'
                ? 'bg-lime-500/15 text-lime-300 border border-lime-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Award className="w-3.5 h-3.5 text-lime-400" />
            <span>AI / ML Engineer Resume</span>
          </button>

          <button
            onClick={() => setActiveTab('transcript')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg font-medium transition-all ${
              activeTab === 'transcript'
                ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <GraduationCap className="w-3.5 h-3.5 text-cyan-400" />
            <span>Academic Transcript (UPES)</span>
          </button>
        </div>

        {/* Highlight Banner */}
        <div className="px-6 py-2 bg-slate-950/60 border-b border-slate-800/80 flex items-center justify-between text-xs text-slate-300">
          <div className="flex items-center gap-2 overflow-x-auto py-0.5 scrollbar-none">
            {currentDoc.highlights.map((h, i) => (
              <span key={i} className="inline-flex items-center gap-1 shrink-0 px-2.5 py-0.5 rounded-full bg-slate-800/80 text-[11px] text-slate-300 border border-slate-700/60">
                <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                <span>{h}</span>
              </span>
            ))}
          </div>
          <a
            href={currentDoc.path}
            target="_blank"
            rel="noopener noreferrer"
            className="text-slate-400 hover:text-white flex items-center gap-1 shrink-0 ml-3 text-[11px]"
          >
            <span>Open in Tab</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>

        {/* PDF Viewer Frame */}
        <div className="flex-1 bg-slate-950 relative overflow-hidden">
          <iframe
            src={`${currentDoc.path}#toolbar=0&navpanes=0`}
            title={currentDoc.title}
            className="w-full h-full border-none"
          />
        </div>
      </div>
    </div>
  );
}
