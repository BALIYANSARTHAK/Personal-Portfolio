import React, { useState } from 'react';
import { Sparkles, TrendingUp, Bot, Truck, Layers } from 'lucide-react';
import PaymentLeakageSimulator from './PaymentLeakageSimulator';
import TalentScoutDemo from './TalentScoutDemo';
import ChokeScoreCalculator from './ChokeScoreCalculator';

interface InteractiveLabProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export default function InteractiveLabSection({ activeTab, setActiveTab }: InteractiveLabProps) {
  return (
    <section id="interactive-lab" className="py-16 lg:py-24 border-b border-slate-800/80 bg-slate-950/60 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            <span>Interactive Engineering Sandbox</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Live Analytics &amp; AI Simulation Lab
          </h2>
          <p className="text-sm sm:text-base text-slate-400 mt-2">
            Instead of just reading descriptions, test the actual analytical models, prioritization formulas, and fault-tolerant AI logic in real time.
          </p>

          {/* Interactive Mode Picker */}
          <div className="inline-flex p-1.5 bg-slate-900 border border-slate-800 rounded-2xl gap-1.5 mt-8 max-w-full overflow-x-auto text-xs font-semibold">
            <button
              onClick={() => setActiveTab('payment-simulator')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'payment-simulator'
                  ? 'bg-emerald-500 text-slate-950 shadow-md font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <TrendingUp className="w-4 h-4" />
              <span>Payment Leakage Recovery (₹1.3M)</span>
            </button>

            <button
              onClick={() => setActiveTab('talentscout-demo')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'talentscout-demo'
                  ? 'bg-emerald-500 text-slate-950 shadow-md font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Bot className="w-4 h-4" />
              <span>TalentScout AI &amp; Fallback Sandbox</span>
            </button>

            <button
              onClick={() => setActiveTab('choke-score')}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl transition-all whitespace-nowrap ${
                activeTab === 'choke-score'
                  ? 'bg-emerald-500 text-slate-950 shadow-md font-bold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Truck className="w-4 h-4" />
              <span>Warehouse Choke Score (DuckDB)</span>
            </button>
          </div>
        </div>

        {/* Dynamic Interactive Container */}
        <div className="transition-all duration-300">
          {activeTab === 'payment-simulator' && <PaymentLeakageSimulator />}
          {activeTab === 'talentscout-demo' && <TalentScoutDemo />}
          {activeTab === 'choke-score' && <ChokeScoreCalculator />}
        </div>
      </div>
    </section>
  );
}
