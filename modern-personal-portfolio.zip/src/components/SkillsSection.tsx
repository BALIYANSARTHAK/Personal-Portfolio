import React, { useState } from 'react';
import { 
  Database, 
  BarChart3, 
  Cpu, 
  Layers, 
  CheckCircle, 
  Search, 
  Sparkles,
  Award
} from 'lucide-react';
import { SKILL_CATEGORIES } from '../data/portfolioData';

export default function SkillsSection() {
  const [searchQuery, setSearchQuery] = useState('');

  const iconMap: Record<string, React.ReactNode> = {
    Database: <Database className="w-5 h-5 text-emerald-400" />,
    BarChart3: <BarChart3 className="w-5 h-5 text-cyan-400" />,
    Cpu: <Cpu className="w-5 h-5 text-lime-400" />,
    Layers: <Layers className="w-5 h-5 text-purple-400" />
  };

  return (
    <section id="skills" className="py-16 lg:py-24 border-b border-slate-800/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-3">
              <Award className="w-3.5 h-3.5" />
              <span>Technical Repertoire</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              Skills &amp; Analytical Competencies
            </h2>
            <p className="text-sm sm:text-base text-slate-400 mt-2 max-w-2xl">
              Grounded in real business problem solving. Categorized by functional capability with verified project application.
            </p>
          </div>

          {/* Quick Skill Search */}
          <div className="relative w-full md:w-64">
            <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search skills (e.g. SQL, Power BI)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500/50 transition-colors"
            />
          </div>
        </div>

        {/* Skill Groups Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {SKILL_CATEGORIES.map((cat, idx) => {
            const filteredSkills = cat.skills.filter(s => 
              s.name.toLowerCase().includes(searchQuery.toLowerCase())
            );

            if (searchQuery && filteredSkills.length === 0) return null;

            return (
              <div
                key={idx}
                className="p-6 rounded-2xl bg-slate-900/60 border border-slate-800/80 hover:border-slate-700/80 transition-all duration-300"
              >
                <div className="flex items-center gap-3 mb-5 pb-4 border-b border-slate-800/80">
                  <div className="w-10 h-10 rounded-xl bg-slate-950 border border-slate-800 flex items-center justify-center">
                    {iconMap[cat.icon]}
                  </div>
                  <div>
                    <h3 className="text-base font-bold text-white">
                      {cat.title}
                    </h3>
                    <div className="text-xs text-slate-400">
                      {filteredSkills.length} competencies identified
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-2.5">
                  {filteredSkills.map((skill, sIdx) => (
                    <div
                      key={sIdx}
                      className="p-3 rounded-xl bg-slate-950/50 border border-slate-800/60 flex items-center justify-between hover:bg-slate-950/80 transition-colors group"
                    >
                      <div className="flex items-center gap-2.5">
                        <CheckCircle className="w-4 h-4 text-emerald-400 group-hover:scale-110 transition-transform shrink-0" />
                        <span className="text-xs sm:text-sm font-medium text-slate-200">
                          {skill.name}
                        </span>
                      </div>

                      <span className={`px-2 py-0.5 rounded text-[10px] font-mono font-semibold uppercase tracking-wider ${
                        skill.level === 'Advanced'
                          ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/20'
                          : 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/20'
                      }`}>
                        {skill.level}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Analytics Philosophy Banner */}
        <div className="mt-8 p-5 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900/90 to-emerald-950/20 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 shrink-0">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="text-sm font-bold text-white">
                "Code is secondary to business context."
              </div>
              <p className="text-xs text-slate-400">
                Data cleaning and algorithms only matter if they prevent revenue leaks, cut operational churn, or improve decision velocity.
              </p>
            </div>
          </div>
          <a
            href="#contact"
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 self-start sm:self-center transition-colors whitespace-nowrap"
          >
            Discuss Data Needs ↗
          </a>
        </div>
      </div>
    </section>
  );
}
