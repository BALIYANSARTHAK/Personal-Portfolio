import React from 'react';
import { 
  Briefcase, 
  GraduationCap, 
  Award, 
  Calendar, 
  MapPin, 
  CheckCircle2, 
  FileText,
  ExternalLink,
  ChevronRight
} from 'lucide-react';
import { EXPERIENCES, EDUCATION, CERTIFICATIONS } from '../data/portfolioData';

interface ExperienceEducationProps {
  onOpenResume: (tab?: 'data-analyst' | 'ai-ml' | 'transcript') => void;
}

export default function ExperienceEducation({ onOpenResume }: ExperienceEducationProps) {
  return (
    <section id="experience" className="py-16 lg:py-24 border-b border-slate-800/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Left Column: Work Experience & Certifications */}
          <div>
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400">
                  <Briefcase className="w-4 h-4" />
                </div>
                <h2 className="text-2xl font-bold text-white tracking-tight">
                  Professional Experience
                </h2>
              </div>
              <button
                onClick={() => onOpenResume('ai-ml')}
                className="text-xs font-semibold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 cursor-pointer"
              >
                <span>View Full CV</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-6">
              {EXPERIENCES.map((exp, idx) => (
                <div
                  key={idx}
                  className="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 relative hover:border-slate-700 transition-colors"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-2">
                    <h3 className="text-base font-bold text-white">
                      {exp.role}
                    </h3>
                    <div className="flex items-center gap-3 text-xs text-slate-400 font-mono">
                      <span className="flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-slate-500" />
                        {exp.period}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-slate-500" />
                        {exp.location}
                      </span>
                    </div>
                  </div>

                  <div className="text-sm font-semibold text-emerald-400 mb-1">
                    {exp.company}
                  </div>
                  <div className="text-xs font-mono text-cyan-300 mb-4 bg-cyan-950/30 px-2.5 py-1 rounded inline-block border border-cyan-500/20">
                    Project: {exp.project}
                  </div>

                  <ul className="space-y-2.5 text-xs text-slate-300">
                    {exp.highlights.map((h, hIdx) => (
                      <li key={hIdx} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                        <span className="leading-relaxed">{h}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>

            {/* Certifications Card */}
            <div className="mt-8 pt-8 border-t border-slate-800/80">
              <div className="flex items-center gap-2.5 mb-5">
                <div className="w-8 h-8 rounded-lg bg-lime-500/10 border border-lime-500/20 flex items-center justify-center text-lime-400">
                  <Award className="w-4 h-4" />
                </div>
                <h3 className="text-lg font-bold text-white">
                  Industry Certifications
                </h3>
              </div>

              {CERTIFICATIONS.map((cert, cIdx) => (
                <div
                  key={cIdx}
                  className="p-5 rounded-2xl bg-slate-900/50 border border-slate-800 hover:border-slate-700 transition-colors"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase tracking-wider bg-lime-500/10 text-lime-300 border border-lime-500/20 inline-block mb-1.5">
                        {cert.badge}
                      </span>
                      <h4 className="text-sm font-bold text-white">
                        {cert.title}
                      </h4>
                      <p className="text-xs text-slate-400 mt-0.5">
                        Issuer: {cert.issuer} • {cert.date}
                      </p>
                    </div>
                  </div>
                  <p className="text-xs text-slate-300 mt-2.5 leading-relaxed">
                    {cert.description}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Right Column: Education & Academic Records */}
          <div>
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400">
                  <GraduationCap className="w-4 h-4" />
                </div>
                <h2 className="text-2xl font-bold text-white tracking-tight">
                  Education &amp; Academic Honors
                </h2>
              </div>
              <button
                onClick={() => onOpenResume('transcript')}
                className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1 cursor-pointer"
              >
                <span>View Transcript</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-6">
              {EDUCATION.map((edu, idx) => (
                <div
                  key={idx}
                  className="p-6 rounded-2xl bg-slate-900/70 border border-slate-800 hover:border-slate-700 transition-colors"
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1 mb-1.5">
                    <h3 className="text-sm sm:text-base font-bold text-white">
                      {edu.degree}
                    </h3>
                    <span className="text-xs font-mono text-slate-400">
                      {edu.period}
                    </span>
                  </div>

                  <div className="text-xs sm:text-sm font-medium text-slate-300 mb-2">
                    {edu.institution}
                  </div>

                  {edu.grade && (
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs font-mono font-semibold mb-2">
                      <span>{edu.grade}</span>
                    </div>
                  )}

                  {edu.notes && (
                    <p className="text-xs text-slate-400 leading-relaxed mt-1">
                      {edu.notes}
                    </p>
                  )}
                </div>
              ))}
            </div>

            {/* Quick Transcript Verification Callout */}
            <div className="mt-8 p-5 rounded-2xl bg-cyan-950/20 border border-cyan-500/30 flex items-center justify-between gap-4">
              <div>
                <div className="text-xs uppercase tracking-wider font-bold text-cyan-300 mb-1">
                  Official UPES Transcript Verified
                </div>
                <p className="text-xs text-slate-300">
                  Full 8-semester course completion and SGPA breakdown available in PDF format.
                </p>
              </div>
              <button
                onClick={() => onOpenResume('transcript')}
                className="px-3.5 py-2 rounded-xl bg-cyan-500/15 text-cyan-300 hover:bg-cyan-500 hover:text-slate-950 text-xs font-semibold border border-cyan-500/30 transition-all shrink-0 cursor-pointer"
              >
                Inspect Transcript
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
