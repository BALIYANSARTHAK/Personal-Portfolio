import React, { useState } from 'react';
import { 
  Copy, 
  Check, 
  FileText, 
  Github, 
  Linkedin, 
  Mail, 
  Menu, 
  X, 
  Sparkles,
  ChevronDown
} from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

interface NavbarProps {
  onOpenResume: (tab?: 'data-analyst' | 'ai-ml') => void;
}

export default function Navbar({ onOpenResume }: NavbarProps) {
  const [copied, setCopied] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [resumeMenuOpen, setResumeMenuOpen] = useState(false);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(PERSONAL_INFO.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2200);
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-slate-950/80 border-b border-slate-800/80 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand identity */}
        <div className="flex items-center gap-3">
          <a href="#" className="flex items-center gap-2.5 group">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-400 to-lime-500 text-slate-950 font-bold font-mono flex items-center justify-center text-sm shadow-lg shadow-emerald-500/20 group-hover:scale-105 transition-transform">
              SB
            </div>
            <div>
              <div className="text-sm font-bold text-white group-hover:text-emerald-400 transition-colors">
                {PERSONAL_INFO.name}
              </div>
              <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                <span className="hidden sm:inline">Data Analyst &amp; AI Developer</span>
                <span className="sm:hidden">Portfolio</span>
              </div>
            </div>
          </a>

          {/* Recruiter availability badge */}
          <div className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[11px] font-medium">
            <Sparkles className="w-3 h-3 text-emerald-400" />
            <span>Open to Work</span>
          </div>
        </div>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-xs font-medium text-slate-300">
          <a href="#case-studies" className="hover:text-emerald-400 transition-colors">
            Case Studies
          </a>
          <a href="#interactive-lab" className="hover:text-emerald-400 transition-colors">
            Analytics Lab
          </a>
          <a href="#skills" className="hover:text-emerald-400 transition-colors">
            Skills &amp; Tools
          </a>
          <a href="#experience" className="hover:text-emerald-400 transition-colors">
            Experience &amp; Education
          </a>
          <a href="#contact" className="hover:text-emerald-400 transition-colors">
            Contact
          </a>
        </nav>

        {/* Action Controls & Socials */}
        <div className="hidden sm:flex items-center gap-2.5">
          {/* Quick Copy Email Button */}
          <button
            onClick={handleCopyEmail}
            title="Click to copy email address"
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 text-xs font-mono transition-all"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Copied!</span>
              </>
            ) : (
              <>
                <Mail className="w-3.5 h-3.5 text-slate-400" />
                <span className="truncate max-w-[130px]">{PERSONAL_INFO.email}</span>
                <Copy className="w-3 h-3 text-slate-500" />
              </>
            )}
          </button>

          {/* GitHub Link */}
          <a
            href={PERSONAL_INFO.github}
            target="_blank"
            rel="noopener noreferrer"
            title="GitHub Profile"
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition-colors"
          >
            <Github className="w-4 h-4" />
          </a>

          {/* LinkedIn Link */}
          <a
            href={PERSONAL_INFO.linkedin}
            target="_blank"
            rel="noopener noreferrer"
            title="LinkedIn Profile"
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-cyan-400 hover:border-slate-700 transition-colors"
          >
            <Linkedin className="w-4 h-4" />
          </a>

          {/* Resume Dropdown / Trigger */}
          <div className="relative">
            <button
              onClick={() => onOpenResume('data-analyst')}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-semibold shadow-md shadow-emerald-500/20 transition-all cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Resume</span>
            </button>
          </div>
        </div>

        {/* Mobile menu hamburger button */}
        <div className="flex sm:hidden items-center gap-2">
          <button
            onClick={() => onOpenResume('data-analyst')}
            className="px-2.5 py-1 rounded-lg bg-emerald-500 text-slate-950 text-xs font-bold"
          >
            Resume
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="sm:hidden px-4 pt-2 pb-5 bg-slate-950 border-b border-slate-800 space-y-3">
          <div className="flex flex-col space-y-2 text-sm text-slate-300 font-medium pt-2">
            <a
              href="#case-studies"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1.5 hover:text-emerald-400"
            >
              Case Studies
            </a>
            <a
              href="#interactive-lab"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1.5 hover:text-emerald-400"
            >
              Analytics Lab
            </a>
            <a
              href="#skills"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1.5 hover:text-emerald-400"
            >
              Skills &amp; Tools
            </a>
            <a
              href="#experience"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1.5 hover:text-emerald-400"
            >
              Experience &amp; Education
            </a>
            <a
              href="#contact"
              onClick={() => setMobileMenuOpen(false)}
              className="py-1.5 hover:text-emerald-400"
            >
              Contact
            </a>
          </div>

          <div className="pt-3 border-t border-slate-800 flex items-center justify-between">
            <button
              onClick={handleCopyEmail}
              className="flex items-center gap-2 text-xs text-slate-300 bg-slate-900 px-3 py-2 rounded-lg border border-slate-800"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied!' : 'Copy Email'}</span>
            </button>

            <div className="flex items-center gap-2">
              <a
                href={PERSONAL_INFO.github}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300"
              >
                <Github className="w-4 h-4" />
              </a>
              <a
                href={PERSONAL_INFO.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 rounded-lg bg-slate-900 border border-slate-800 text-slate-300"
              >
                <Linkedin className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
