import React, { useState } from 'react';
import { 
  BarChart3, 
  Bot, 
  Layers, 
  CheckCircle2, 
  ArrowUpRight, 
  Github, 
  ChevronDown, 
  ChevronUp, 
  Code2, 
  Sparkles,
  Zap
} from 'lucide-react';
import { PROJECTS, ProjectItem } from '../data/portfolioData';

interface CaseStudiesProps {
  onSelectInteractive: (type: string) => void;
}

export default function CaseStudies({ onSelectInteractive }: CaseStudiesProps) {
  const [filter, setFilter] = useState<'all' | 'data-analytics' | 'ai-ml'>('all');
  const [expandedCodeId, setExpandedCodeId] = useState<string | null>(null);

  const filteredProjects = PROJECTS.filter(p => {
    if (filter === 'all') return true;
    return p.category === filter;
  });

  const toggleCode = (id: string) => {
    setExpandedCodeId(expandedCodeId === id ? null : id);
  };

  return (
    <section id="case-studies" className="py-16 lg:py-24 border-b border-slate-800/80 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-slate-900 border border-slate-800 text-emerald-400 text-xs font-semibold uppercase tracking-wider mb-3">
              <Zap className="w-3.5 h-3.5" />
              <span>Evidence-Based Engineering</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              Featured Case Studies &amp; Projects
            </h2>
            <p className="text-sm sm:text-base text-slate-400 mt-2 max-w-2xl">
              Real-world datasets, verified business ROI, and engineered software solutions — zero invented metrics.
            </p>
          </div>

          {/* Category Filter Tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-slate-900 border border-slate-800 rounded-xl text-xs font-medium self-start md:self-auto">
            <button
              onClick={() => setFilter('all')}
              className={`px-3.5 py-1.5 rounded-lg transition-all ${
                filter === 'all'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              All Projects ({PROJECTS.length})
            </button>
            <button
              onClick={() => setFilter('data-analytics')}
              className={`px-3.5 py-1.5 rounded-lg transition-all ${
                filter === 'data-analytics'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Data Analytics ({PROJECTS.filter(p => p.category === 'data-analytics').length})
            </button>
            <button
              onClick={() => setFilter('ai-ml')}
              className={`px-3.5 py-1.5 rounded-lg transition-all ${
                filter === 'ai-ml'
                  ? 'bg-emerald-500 text-slate-950 font-bold shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              Applied AI/ML ({PROJECTS.filter(p => p.category === 'ai-ml').length})
            </button>
          </div>
        </div>

        {/* Project Cards Grid */}
        <div className="space-y-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              className={`rounded-2xl border transition-all duration-300 overflow-hidden ${
                project.featured
                  ? 'bg-slate-900/80 border-slate-700/80 shadow-xl'
                  : 'bg-slate-900/50 border-slate-800/80 hover:border-slate-700'
              }`}
            >
              <div className="p-6 sm:p-8">
                {/* Header Row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-800">
                  <div>
                    <div className="flex items-center gap-2.5 mb-2">
                      <span className={`px-2.5 py-0.5 rounded-md text-[11px] font-semibold uppercase tracking-wider font-mono ${
                        project.category === 'data-analytics'
                          ? 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/20'
                          : 'bg-cyan-500/10 text-cyan-300 border border-cyan-500/20'
                      }`}>
                        {project.badge}
                      </span>
                      {project.featured && (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-amber-500/10 text-amber-300 border border-amber-500/20">
                          Primary Portfolio Case
                        </span>
                      )}
                    </div>
                    <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                      {project.title}
                    </h3>
                    <p className="text-sm text-slate-400 mt-1">
                      {project.tagline}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 self-start sm:self-center">
                    {project.interactiveType && (
                      <button
                        onClick={() => onSelectInteractive(project.interactiveType!)}
                        className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 hover:bg-emerald-500 hover:text-slate-950 text-xs font-semibold transition-all shadow-sm cursor-pointer"
                      >
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Try Interactive Demo</span>
                      </button>
                    )}

                    {project.githubUrl && (
                      <a
                        href={project.githubUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-medium border border-slate-700 transition-colors"
                      >
                        <Github className="w-3.5 h-3.5" />
                        <span>Repo</span>
                        <ArrowUpRight className="w-3 h-3 opacity-60" />
                      </a>
                    )}
                  </div>
                </div>

                {/* Metrics Pill Strip */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 my-5">
                  {project.metrics.map((m, i) => (
                    <div key={i} className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80">
                      <div className="text-[11px] font-medium text-slate-400 truncate">{m.label}</div>
                      <div className="text-base sm:text-lg font-bold font-mono text-emerald-400 mt-0.5">
                        {m.value}
                      </div>
                    </div>
                  ))}
                </div>

                {/* Problem & Solution Split */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-6 text-xs sm:text-sm">
                  <div className="p-4 rounded-xl bg-slate-950/40 border border-slate-800/60">
                    <div className="text-xs font-semibold uppercase tracking-wider text-rose-400 mb-1.5 flex items-center gap-1.5">
                      <span>The Business Challenge</span>
                    </div>
                    <p className="text-slate-300 leading-relaxed">
                      {project.problem}
                    </p>
                  </div>

                  <div className="p-4 rounded-xl bg-slate-950/40 border border-slate-800/60">
                    <div className="text-xs font-semibold uppercase tracking-wider text-emerald-400 mb-1.5 flex items-center gap-1.5">
                      <span>Analytical / Engineering Solution</span>
                    </div>
                    <p className="text-slate-300 leading-relaxed">
                      {project.solution}
                    </p>
                  </div>
                </div>

                {/* Core Contributions List */}
                <div className="mt-4 pt-4 border-t border-slate-800/60">
                  <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
                    Key Technical Contributions:
                  </div>
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-2.5 text-xs text-slate-300">
                    {project.contributions.map((c, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span className="leading-relaxed">{c}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Tools Used Strip */}
                <div className="mt-5 flex flex-wrap items-center justify-between gap-3 pt-4 border-t border-slate-800/60">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="text-slate-500 text-xs font-medium mr-1">Tools:</span>
                    {project.tools.map((tool) => (
                      <span
                        key={tool}
                        className="px-2 py-0.5 rounded-md bg-slate-800/80 border border-slate-700/60 text-slate-300 font-mono text-[11px]"
                      >
                        {tool}
                      </span>
                    ))}
                  </div>

                  {project.codeSnippet && (
                    <button
                      onClick={() => toggleCode(project.id)}
                      className="inline-flex items-center gap-1.5 text-xs font-mono text-cyan-400 hover:text-cyan-300 transition-colors"
                    >
                      <Code2 className="w-3.5 h-3.5" />
                      <span>{expandedCodeId === project.id ? 'Hide Source Query' : 'Inspect SQL Query'}</span>
                      {expandedCodeId === project.id ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                    </button>
                  )}
                </div>

                {/* Expandable Code Snippet Drawer */}
                {project.codeSnippet && expandedCodeId === project.id && (
                  <div className="mt-4 rounded-xl border border-slate-800 bg-slate-950 p-4 overflow-hidden animate-in fade-in duration-200">
                    <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 text-[11px] font-mono text-slate-400">
                      <span>{project.codeSnippet.filename}</span>
                      <span className="uppercase text-cyan-400">{project.codeSnippet.language}</span>
                    </div>
                    <pre className="font-mono text-xs text-emerald-300/90 overflow-x-auto leading-relaxed">
                      {project.codeSnippet.code}
                    </pre>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
