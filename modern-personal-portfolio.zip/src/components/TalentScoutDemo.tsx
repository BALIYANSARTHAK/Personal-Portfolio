import React, { useState } from 'react';
import { Bot, ShieldAlert, Cpu, CheckCircle2, ArrowRight, Sparkles, Terminal, RefreshCw, AlertCircle } from 'lucide-react';

interface QuestionMock {
  skill: string;
  role: string;
  question: string;
  difficulty: 'Junior' | 'Mid' | 'Senior';
  expectedConcepts: string[];
  evaluationCriteria: string;
  source: 'LLM_PROMPT_ENGINE' | 'DETERMINISTIC_FALLBACK_ENGINE';
  latencyMs: number;
}

const QUESTION_BANK: Record<string, { online: QuestionMock; fallback: QuestionMock }> = {
  "SQL Window Functions": {
    online: {
      role: "Data Analyst",
      skill: "SQL Window Functions",
      difficulty: "Junior",
      question: "Explain when you would use LEAD() or LAG() instead of a self-join in transactional data, and provide an example calculating day-over-day revenue drop.",
      expectedConcepts: ["Window partitioning", "Offset calculation without self-join complexity", "LEAD() for forward-looking telemetry"],
      evaluationCriteria: "Candidate recognizes performance gains of in-memory window framing over expensive cartesian joins.",
      source: "LLM_PROMPT_ENGINE",
      latencyMs: 380
    },
    fallback: {
      role: "Data Analyst",
      skill: "SQL Window Functions",
      difficulty: "Junior",
      question: "[FALLBACK RULE ENGINE] Write a SQL query using ROW_NUMBER() or DENSE_RANK() to find the top 2 highest failure rate payment segments per gateway.",
      expectedConcepts: ["DENSE_RANK() over PARTITION BY gateway_id", "Handling tied metrics", "Subquery filtering"],
      evaluationCriteria: "Correct syntax partitioning by gateway and filtering rank <= 2 in outer query.",
      source: "DETERMINISTIC_FALLBACK_ENGINE",
      latencyMs: 4
    }
  },
  "Power BI & DAX": {
    online: {
      role: "Business Intelligence Analyst",
      skill: "Power BI & DAX",
      difficulty: "Junior",
      question: "How do you handle calculating cumulative Year-to-Date (YTD) sales when transaction dates contain missing business days in Power BI?",
      expectedConcepts: ["Dedicated Date Dimension Table", "TOTALYTD() vs CALCULATE(FILTER(...))", "Date relationships without bi-directional traps"],
      evaluationCriteria: "Identifies need for a contiguous calendar table rather than raw fact table timestamps.",
      source: "LLM_PROMPT_ENGINE",
      latencyMs: 420
    },
    fallback: {
      role: "Business Intelligence Analyst",
      skill: "Power BI & DAX",
      difficulty: "Junior",
      question: "[FALLBACK RULE ENGINE] What is the exact difference between a DAX Calculated Column and a DAX Measure in terms of memory and row context?",
      expectedConcepts: ["Row context vs Filter context", "RAM storage at data refresh vs CPU computation at query time"],
      evaluationCriteria: "Understands measures consume CPU on visual render; calculated columns consume disk RAM.",
      source: "DETERMINISTIC_FALLBACK_ENGINE",
      latencyMs: 3
    }
  },
  "Python Data Cleaning (Pandas)": {
    online: {
      role: "Data Analyst / ML Engineer",
      skill: "Python Data Cleaning (Pandas)",
      difficulty: "Junior",
      question: "In a real dataset with 8,399 rows, you find inconsistent categorical spellings and missing values. How do you clean this without dropping rows?",
      expectedConcepts: [".str.strip() and .str.lower() normalization", "Domain-guided imputation", "Data type casting with astype()"],
      evaluationCriteria: "Prioritizes data integrity over simplistic dropna() that loses business sample size.",
      source: "LLM_PROMPT_ENGINE",
      latencyMs: 350
    },
    fallback: {
      role: "Data Analyst / ML Engineer",
      skill: "Python Data Cleaning (Pandas)",
      difficulty: "Junior",
      question: "[FALLBACK RULE ENGINE] Given a DataFrame 'df' with column 'revenue' formatted as strings with currency symbols ('₹1,200'), write the one-line Pandas code to convert it to float.",
      expectedConcepts: ["df['revenue'].str.replace('₹', '').str.replace(',', '').astype(float)"],
      evaluationCriteria: "Proper regex/string stripping and numerical type conversion.",
      source: "DETERMINISTIC_FALLBACK_ENGINE",
      latencyMs: 2
    }
  },
  "Imbalanced ML & Fraud Classification": {
    online: {
      role: "Junior AI/ML Developer",
      skill: "Imbalanced ML & Fraud Classification",
      difficulty: "Junior",
      question: "When predicting financial fraud on 6.36 million rows where fraud represents 0.1%, why is 99.9% accuracy a failed model, and which evaluation metric would you optimize?",
      expectedConcepts: ["Accuracy Paradox", "Minority Class Recall", "ROC-AUC & Precision-Recall AUC", "Cost of False Negatives"],
      evaluationCriteria: "Candidate prioritizes Recall/PR-AUC because missing an actual fraud case incurs direct monetary loss.",
      source: "LLM_PROMPT_ENGINE",
      latencyMs: 410
    },
    fallback: {
      role: "Junior AI/ML Developer",
      skill: "Imbalanced ML & Fraud Classification",
      difficulty: "Junior",
      question: "[FALLBACK RULE ENGINE] Explain how Random Forest class_weight='balanced' or SMOTE synthetic sampling alters the loss penalty for the rare fraud class.",
      expectedConcepts: ["Inverse frequency loss weighting", "Synthetic minority oversampling in feature space"],
      evaluationCriteria: "Understands penalizing minority class misclassifications higher in the objective function.",
      source: "DETERMINISTIC_FALLBACK_ENGINE",
      latencyMs: 4
    }
  }
};

export default function TalentScoutDemo() {
  const [selectedSkill, setSelectedSkill] = useState<string>("SQL Window Functions");
  const [simulateOutage, setSimulateOutage] = useState<boolean>(false);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [currentView, setCurrentView] = useState<'card' | 'json'>('card');

  const activeData = simulateOutage 
    ? QUESTION_BANK[selectedSkill].fallback 
    : QUESTION_BANK[selectedSkill].online;

  const handleSkillChange = (skill: string) => {
    setIsGenerating(true);
    setSelectedSkill(skill);
    setTimeout(() => {
      setIsGenerating(false);
    }, 200);
  };

  const handleToggleOutage = () => {
    setIsGenerating(true);
    setSimulateOutage(!simulateOutage);
    setTimeout(() => {
      setIsGenerating(false);
    }, 180);
  };

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 lg:p-8 backdrop-blur-xl shadow-2xl">
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-6 border-b border-slate-800 gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-lime-400 mb-1">
            <Bot className="w-4 h-4" />
            <span>Interactive AI Sandbox &amp; Fault-Tolerance Test</span>
          </div>
          <h3 className="text-xl font-bold text-white">TalentScout Resilient Interview Engine</h3>
          <p className="text-sm text-slate-400">
            Test how Sarthak engineered structured prompt generation with zero-downtime offline rule fallbacks.
          </p>
        </div>

        {/* Live Fallback Toggle */}
        <button
          onClick={handleToggleOutage}
          className={`flex items-center gap-2.5 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all border ${
            simulateOutage
              ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 ring-2 ring-amber-500/20'
              : 'bg-slate-800/80 border-slate-700 text-slate-300 hover:border-slate-600'
          }`}
        >
          <div className={`w-2.5 h-2.5 rounded-full ${simulateOutage ? 'bg-amber-400 animate-ping' : 'bg-emerald-400'}`}></div>
          <span>{simulateOutage ? 'API Outage Simulated (Fallback Active)' : 'API Status: Normal (LLM Online)'}</span>
        </button>
      </div>

      {/* Control Strip */}
      <div className="my-6">
        <label className="text-xs font-semibold uppercase tracking-wider text-slate-400 block mb-2">
          Select Candidate Skill Area to Test:
        </label>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {Object.keys(QUESTION_BANK).map((skill) => (
            <button
              key={skill}
              onClick={() => handleSkillChange(skill)}
              className={`p-2.5 text-xs rounded-xl font-medium text-left transition-all border ${
                selectedSkill === skill
                  ? 'bg-lime-500/15 border-lime-500/40 text-lime-300 shadow-sm'
                  : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700'
              }`}
            >
              <div className="truncate">{skill}</div>
            </button>
          ))}
        </div>
      </div>

      {/* Output Screen */}
      <div className="rounded-xl border border-slate-800 bg-slate-950 overflow-hidden">
        {/* Terminal Header */}
        <div className="flex items-center justify-between px-4 py-2.5 bg-slate-900 border-b border-slate-800 text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-rose-500/80"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80"></span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80"></span>
            <span className="font-mono text-slate-400 text-[11px] ml-2">
              talentscout_pipeline/{simulateOutage ? 'rule_fallback_engine.py' : 'llm_structured_prompt.py'}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono text-slate-400">
              Latency: <strong className={simulateOutage ? 'text-amber-400' : 'text-emerald-400'}>{activeData.latencyMs}ms</strong>
            </span>
            <div className="flex bg-slate-800 p-0.5 rounded-md text-[10px]">
              <button
                onClick={() => setCurrentView('card')}
                className={`px-2 py-0.5 rounded ${currentView === 'card' ? 'bg-slate-700 text-white' : 'text-slate-400'}`}
              >
                Card View
              </button>
              <button
                onClick={() => setCurrentView('json')}
                className={`px-2 py-0.5 rounded ${currentView === 'json' ? 'bg-slate-700 text-white' : 'text-slate-400'}`}
              >
                JSON Contract
              </button>
            </div>
          </div>
        </div>

        {/* Dynamic Content */}
        <div className="p-5">
          {isGenerating ? (
            <div className="py-12 flex flex-col items-center justify-center text-slate-400 text-xs">
              <RefreshCw className="w-5 h-5 animate-spin text-lime-400 mb-2" />
              <span>Synthesizing tailored assessment question...</span>
            </div>
          ) : currentView === 'card' ? (
            <div>
              <div className="flex items-center gap-2 mb-3">
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider bg-slate-800 text-slate-300">
                  Target Role: {activeData.role}
                </span>
                <span className="px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
                  Level: {activeData.difficulty}
                </span>
                <span className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase tracking-wider font-mono ${
                  simulateOutage 
                    ? 'bg-amber-500/10 text-amber-300 border border-amber-500/20'
                    : 'bg-emerald-500/10 text-emerald-300 border border-emerald-500/20'
                }`}>
                  {simulateOutage ? 'Deterministic Fallback' : 'OpenAI Structured Schema'}
                </span>
              </div>

              <div className="text-base sm:text-lg font-medium text-slate-100 leading-snug mb-4">
                "{activeData.question}"
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-slate-800/80 text-xs">
                <div>
                  <div className="text-slate-400 font-medium mb-1.5 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-lime-400" />
                    Expected Technical Concepts:
                  </div>
                  <ul className="space-y-1 text-slate-300">
                    {activeData.expectedConcepts.map((c, i) => (
                      <li key={i} className="flex items-start gap-1.5">
                        <span className="text-lime-400">▹</span>
                        <span>{c}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <div className="text-slate-400 font-medium mb-1.5 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400" />
                    Interviewer Evaluation Rubric:
                  </div>
                  <p className="text-slate-300 leading-relaxed bg-slate-900/60 p-2.5 rounded-lg border border-slate-800/60">
                    {activeData.evaluationCriteria}
                  </p>
                </div>
              </div>
            </div>
          ) : (
            <pre className="font-mono text-xs text-lime-300/90 overflow-x-auto p-2 leading-relaxed">
              {JSON.stringify(
                {
                  status: simulateOutage ? "FALLBACK_TRIGGERED" : "SUCCESS",
                  http_status: simulateOutage ? 503 : 200,
                  engine: activeData.source,
                  latency_ms: activeData.latencyMs,
                  payload: {
                    target_role: activeData.role,
                    skill: activeData.skill,
                    difficulty: activeData.difficulty,
                    question_text: activeData.question,
                    expected_concepts: activeData.expectedConcepts,
                    evaluation_rubric: activeData.evaluationCriteria
                  }
                },
                null,
                2
              )}
            </pre>
          )}
        </div>
      </div>

      {/* Architecture Rationale */}
      <div className="mt-4 p-3 rounded-lg bg-slate-950/60 border border-slate-800/60 text-xs text-slate-400 flex items-start gap-2.5">
        <Cpu className="w-4 h-4 text-lime-400 mt-0.5 shrink-0" />
        <div>
          <strong className="text-slate-200">Engineering Distinction:</strong> Most junior AI projects simply call an LLM API and crash when the rate-limit triggers. Sarthak built an enterprise-grade fallback architecture where the candidate screening session proceeds seamlessly without dropped interviews or disrupted HR workflows.
        </div>
      </div>
    </div>
  );
}
