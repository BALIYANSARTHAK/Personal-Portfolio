export interface ProjectItem {
  id: string;
  title: string;
  category: 'data-analytics' | 'ai-ml' | 'data-engineering';
  tagline: string;
  badge: string;
  tools: string[];
  metrics: { label: string; value: string }[];
  problem: string;
  solution: string;
  contributions: string[];
  results: string[];
  githubUrl?: string;
  featured: boolean;
  interactiveType?: 'payment-simulator' | 'talentscout-demo' | 'choke-score' | 'dashboard-preview';
  codeSnippet?: {
    language: string;
    filename: string;
    code: string;
  };
}

export interface ExperienceItem {
  role: string;
  company: string;
  project: string;
  location: string;
  period: string;
  highlights: string[];
}

export interface EducationItem {
  degree: string;
  institution: string;
  period: string;
  grade?: string;
  notes?: string;
}

export const PERSONAL_INFO = {
  name: "Sarthak Baliyan",
  headline: "Aspiring Data Analyst | AI/ML Developer",
  subheadline: "Turning complex transactional & shipment logs into high-impact recovery strategies and engineering resilient, prompt-orchestrated AI applications.",
  email: "2003baliyansarthak@gmail.com",
  phone: "+91-7060092284",
  location: "India (Open to Remote & On-site)",
  status: "Actively interviewing for Data Analyst & Junior AI/ML roles",
  github: "https://github.com/BALIYANSARTHAK",
  linkedin: "https://www.linkedin.com/in/sarthak-baliyan-549a51342/",
  resumes: {
    dataAnalyst: "/assets/aistudio/Sarthak_Baliyan_Data_Analyst_Resume_6ee55305.pdf",
    aiMl: "/assets/aistudio/Sarthak_Baliyan_AI-ML_Resume_0c418cb9.pdf"
  },
  keyMetrics: [
    { label: "Recoverable Revenue Identified", value: "₹13,01,381", sub: "Payment failure analysis across 242 segments", highlight: true },
    { label: "Transactions Analyzed", value: "30,000+", sub: "Granular failure pattern & root-cause isolation" },
    { label: "Fraud Detection Dataset", value: "6.36M+", sub: "Imbalanced class ML (Recall & ROC-AUC priority)" },
    { label: "Traffic Detection Accuracy", value: "+30%", sub: "Over baseline heuristics at IBM SkillsBuild" }
  ]
};

export const PROJECTS: ProjectItem[] = [
  {
    id: "payment-leakage",
    title: "Payment Revenue Leakage & Failure Prioritization",
    category: "data-analytics",
    tagline: "Uncovering silent transaction drops & ranking high-yield recovery pipelines",
    badge: "Flagship Analytics Project",
    tools: ["Python", "SQL", "Pandas", "Statistical Analysis", "EDA", "Business Insights"],
    featured: true,
    interactiveType: "payment-simulator",
    metrics: [
      { label: "Recoverable Revenue", value: "₹1,301,381" },
      { label: "Total Transactions", value: "30,000" },
      { label: "Failure Rate", value: "5.01%" },
      { label: "Critical Segments", value: "3 Critical / 16 High" }
    ],
    problem: "In payment processing ecosystems, a 5.01% failure rate seems minor on the surface, but hides significant recurring revenue leakage due to unaddressed gateway timeouts, user-dropoffs, and retry inefficiencies.",
    solution: "Analyzed 30,000 transaction records across 242 discrete failure segments. Built an objective priority matrix classifying segments into Critical, High-Priority, and Low-Impact based on recoverable volume and remediation feasibility.",
    contributions: [
      "Extracted, sanitized, and classified 30k payment transaction events across 242 granular failure attribute segments.",
      "Calculated exact baseline failure rates (5.01%) and isolated recurring gateway versus user-authorization errors.",
      "Discovered ₹1,301,381 in recoverable revenue concentrated in just 3 critical segments and 16 high-priority queues.",
      "Developed recommended automated routing and retry rules for engineering teams to capture lost transactions."
    ],
    results: [
      "₹1,301,381 quantified as immediate recoverable revenue pipeline.",
      "Narrowed 242 noisy segments down to 3 high-impact engineering fixes.",
      "Delivered an executive-ready prioritization framework adopted for payment gateway routing."
    ],
    codeSnippet: {
      language: "sql",
      filename: "payment_leakage_prioritization.sql",
      code: `-- Segment-level failure rate and recoverable revenue calculation
WITH SegmentSummary AS (
    SELECT 
        gateway_id,
        payment_method,
        error_code,
        COUNT(*) AS total_transactions,
        SUM(CASE WHEN status = 'FAILED' THEN 1 ELSE 0 END) AS failed_count,
        SUM(CASE WHEN status = 'FAILED' AND is_retryable = 1 THEN amount ELSE 0 END) AS recoverable_leakage
    FROM payment_transactions_30k
    GROUP BY 1, 2, 3
)
SELECT 
    gateway_id,
    payment_method,
    error_code,
    failed_count,
    ROUND((failed_count * 100.0 / total_transactions), 2) AS failure_rate_pct,
    recoverable_leakage,
    CASE 
        WHEN recoverable_leakage > 200000 AND (failed_count * 100.0 / total_transactions) > 8.0 THEN 'CRITICAL_ACTION'
        WHEN recoverable_leakage > 50000 THEN 'HIGH_PRIORITY'
        ELSE 'MONITOR'
    END AS triage_level
FROM SegmentSummary
ORDER BY recoverable_leakage DESC;`
    }
  },
  {
    id: "talentscout-ai",
    title: "TalentScout — AI Hiring Assistant",
    category: "ai-ml",
    tagline: "Skill-conditioned technical interview screening with fault-tolerant fallback cascading",
    badge: "Applied AI / LLM Engineering",
    tools: ["Python", "LLM APIs (OpenAI)", "Prompt Engineering", "Streamlit", "JSON Schema", "Fallback Engine"],
    featured: true,
    interactiveType: "talentscout-demo",
    githubUrl: "https://github.com/BALIYANSARTHAK/TalentScout",
    metrics: [
      { label: "System Uptime", value: "99.9%" },
      { label: "Output Consistency", value: "Structured JSON" },
      { label: "API Fallback", value: "Zero Downtime" },
      { label: "Interface", value: "Streamlit Chat" }
    ],
    problem: "Off-the-shelf LLM chat bots frequently hallucinate irrelevant trivia questions, produce unstructured text that cannot be evaluated programmatically, and fail entirely when API rate limits or outages strike during live interviews.",
    solution: "Engineered a dual-engine architecture: a prompt-conditioned LLM generator enforcing strict JSON response contracts, paired with a deterministic, rule-based offline fallback engine that guarantees question generation even during total API failures.",
    contributions: [
      "Engineered multi-stage prompt templates with role-specific constraints (Junior Data Analyst, Python Dev, ML Engineer).",
      "Enforced strict JSON output schemas for question text, target evaluation criteria, and expected answer benchmarks.",
      "Constructed an offline rule-based fallback question generator that catches 429/500 API exceptions seamlessly.",
      "Built an intuitive Streamlit chat interface featuring session state management and local candidate privacy protection."
    ],
    results: [
      "100% test pass rate on system resilience during simulated third-party API downtime.",
      "Eliminated unstructured parsing failures by validating outputs against defined Pydantic schemas.",
      "Standardized candidate screening rubrics across foundational data and programming disciplines."
    ]
  },
  {
    id: "choked-hub",
    title: "Choked Hub Prioritization — Warehouse Congestion Analytics",
    category: "data-analytics",
    tagline: "End-to-end logistics analytics identifying shipment bottlenecks using SQL window functions",
    badge: "Logistics Analytics",
    tools: ["Python", "SQL (DuckDB)", "LEAD() Window Functions", "Pandas", "Data Wrangling", "JSON Flattening"],
    featured: true,
    interactiveType: "choke-score",
    githubUrl: "https://github.com/BALIYANSARTHAK",
    metrics: [
      { label: "Data Flattened", value: "Raw Nested JSON" },
      { label: "Analysis Engine", value: "DuckDB SQL" },
      { label: "Classification", value: "Weighted Choke Score" },
      { label: "Key Window Fn", value: "LEAD() Over Partitions" }
    ],
    problem: "Modern supply chain operations generate thousands of nested JSON shipment event records. Tracking which distribution centers are congested in real-time is often slowed by unflattened telemetry data and subjective dispatch rules.",
    solution: "Designed an end-to-end analytical pipeline in Python and DuckDB that ingests nested tracking logs, reconstructs package journeys using LEAD() window functions, and scores hubs automatically through a calibrated 4-factor Choke Score.",
    contributions: [
      "Parsed and flattened complex nested JSON shipment-tracking event payloads into a clean tabular schema.",
      "Employed DuckDB window functions (LEAD()) partitioned by shipment ID to calculate warehouse dwell time, backlog volume, and exit failure rates.",
      "Formulated a weighted multi-variable Choke Score: 35% dwell time, 35% pending shipments, 20% volume, and 10% exit failure rate.",
      "Classified facilities into actionable 'Prioritize-for-Clearing' vs 'Normal Flow' queues for operations directors."
    ],
    results: [
      "Replaced subjective warehouse clearing decisions with an objective mathematical ranking model.",
      "Achieved sub-second query performance on tracking datasets using in-process DuckDB vectorized execution."
    ]
  },
  {
    id: "fraud-transactions",
    title: "Predicting Fraudulent Financial Transactions",
    category: "ai-ml",
    tagline: "Imbalanced machine learning classification on 6.36 Million transactions",
    badge: "FinTech Machine Learning",
    tools: ["Python", "Scikit-Learn", "Random Forest", "Decision Trees", "Feature Engineering", "ROC-AUC"],
    featured: false,
    metrics: [
      { label: "Transactions Processed", value: "6.36M+" },
      { label: "Key Metric", value: "Recall & ROC-AUC" },
      { label: "Top Fraud Types", value: "TRANSFER / CASH_OUT" },
      { label: "Model Stack", value: "Ensemble Trees" }
    ],
    problem: "In financial fraud detection, genuine fraud represents less than 0.1% of transactions. Traditional models optimized for raw accuracy fail completely by predicting 'Legitimate' for every transaction while missing actual monetary theft.",
    solution: "Engineered domain-specific balance-delta and transactional velocity features across 6.36M rows. Trained Decision Tree and Random Forest classifiers optimized strictly for Minority Class Recall and Precision-Recall AUC.",
    contributions: [
      "Engineered features including source/destination balance discrepancies, transaction velocity, and amount relative to balance.",
      "Handled severe class imbalance without relying on deceptive accuracy scores.",
      "Identified that TRANSFER and CASH_OUT operations were the primary vehicles for fraudulent transactions."
    ],
    results: [
      "Optimized fraud recall to minimize costly false negatives for financial institutions.",
      "Established clear decision-threshold boundaries between automated blocking and human review."
    ]
  },
  {
    id: "superstore-sales",
    title: "Superstore Sales Performance Analytics",
    category: "data-analytics",
    tagline: "Retail exploratory data analysis uncovering negative margin pockets in 8,399 orders",
    badge: "Business Intelligence",
    tools: ["Python", "Pandas", "Power BI", "DAX", "Data Cleaning", "Dashboard Development"],
    featured: false,
    metrics: [
      { label: "Orders Analyzed", value: "8,399 Records" },
      { label: "Unprofitable Orders", value: "50.8% Discovered" },
      { label: "Rows Dropped", value: "0 (100% Cleansed)" },
      { label: "Dashboard KPIs", value: "4 KPIs & 3 Dynamic Filters" }
    ],
    problem: "A high-volume retail enterprise showed an apparently healthy 10.2% overall margin, masking catastrophic margin bleed in certain regional product segments.",
    solution: "Performed rigorous exploratory data analysis (EDA) with zero row loss. Built an interactive Power BI dashboard exposing that Furniture yielded a meager 2.3% margin compared to 14.8% for Technology on nearly identical sales volume.",
    contributions: [
      "Cleaned an 8,399-record dataset (2009–2012) fixing misaligned data types, irregular text fields, and missing values.",
      "Uncovered that over half (50.8%) of all placed orders were operating at a net loss due to excessive promotional discounting.",
      "Built a multi-tab Power BI dashboard with region, segment, and priority slicers for senior executive exploration.",
      "Authored 5 prioritized strategic recommendations: discount capping, freight restructuring, and product bundling."
    ],
    results: [
      "Provided leadership with clear visibility into unprofitable product lines.",
      "Delivered a repeatable data transformation pipeline template in Pandas."
    ]
  },
  {
    id: "algo-trading-ml",
    title: "Algorithmic Trading & Signal Engine with ML",
    category: "ai-ml",
    tagline: "Technical indicator rule engine & price movement classifier with automated cloud logging",
    badge: "Quantitative Prototype",
    tools: ["Python", "yfinance", "Technical Indicators (RSI, DMA)", "Logistic Regression", "Google Sheets API"],
    featured: false,
    metrics: [
      { label: "Market Tracked", value: "NIFTY 50" },
      { label: "Technical Signals", value: "RSI + 20/50 DMA" },
      { label: "Cloud Integration", value: "Google Sheets API" },
      { label: "Automation", value: "Scheduled Cron Logs" }
    ],
    problem: "Individual traders often suffer from emotional execution delay and lack automated, auditable logging of rule-based trading signals.",
    solution: "Built a Python-based quantitative prototype pulling live market feeds via yfinance, generating BUY/SELL/HOLD signals from momentum indicators, predicting next-day directional momentum with Logistic Regression, and logging trades in Google Sheets.",
    contributions: [
      "Implemented mathematical calculations for RSI, 20-day, and 50-day moving average crossovers.",
      "Trained a Logistic Regression model on historical candlestick features to score directional probabilities.",
      "Integrated Google Sheets API via gspread for real-time audit trails with secure service account credentials."
    ],
    results: [
      "Demonstrated full-stack quantitative automation from market data ingestion to cloud ledger persistence."
    ]
  }
];

export const SKILL_CATEGORIES = [
  {
    title: "Data Analytics & SQL",
    icon: "Database",
    color: "emerald",
    skills: [
      { name: "SQL (Window Functions, CTEs, Joins)", level: "Advanced" },
      { name: "Python (Pandas, NumPy)", level: "Advanced" },
      { name: "Exploratory Data Analysis (EDA)", level: "Advanced" },
      { name: "Data Cleaning & Wrangling", level: "Advanced" },
      { name: "DuckDB & In-Process Analytics", level: "Proficient" },
      { name: "Statistical Analysis & Distribution Modeling", level: "Proficient" }
    ]
  },
  {
    title: "Business Intelligence & Visualization",
    icon: "BarChart3",
    color: "cyan",
    skills: [
      { name: "Power BI (Interactive Dashboards, Modeling)", level: "Advanced" },
      { name: "Streamlit Web Apps", level: "Advanced" },
      { name: "Plotly, Matplotlib & Seaborn", level: "Advanced" },
      { name: "KPI Hierarchy & Business Metrics", level: "Advanced" },
      { name: "Excel (Pivot Tables, VLOOKUP/XLOOKUP)", level: "Proficient" }
    ]
  },
  {
    title: "Applied AI, ML & LLMs",
    icon: "Cpu",
    color: "lime",
    skills: [
      { name: "Prompt Engineering & Structured JSON", level: "Advanced" },
      { name: "LLM API Integration (OpenAI, Gemini)", level: "Advanced" },
      { name: "Fault-Tolerant Fallback Architecture", level: "Advanced" },
      { name: "Scikit-Learn (Random Forest, Trees, Regression)", level: "Proficient" },
      { name: "Imbalanced Class Classification (ROC-AUC)", level: "Proficient" },
      { name: "Computer Vision (YOLOv5/v8, OpenCV)", level: "Proficient" }
    ]
  },
  {
    title: "Data Engineering & Tools",
    icon: "Layers",
    color: "indigo",
    skills: [
      { name: "Data Pipeline Design & JSON Flattening", level: "Proficient" },
      { name: "PDF Extraction (Camelot) & fpdf2", level: "Proficient" },
      { name: "Git, GitHub & Version Control", level: "Advanced" },
      { name: "REST APIs & Cloud Integrations", level: "Proficient" },
      { name: "Jupyter Notebook, VS Code, Google Colab", level: "Advanced" }
    ]
  }
];

export const EXPERIENCES: ExperienceItem[] = [
  {
    role: "Machine Learning Intern",
    company: "IBM SkillsBuild (Pheme Software Pvt. Ltd)",
    project: "Predicting Urban Traffic Patterns — TrafficVision AI",
    location: "Remote",
    period: "2024",
    highlights: [
      "Engineered deep learning-based video pipeline analyzing real-time urban traffic footage, improving congestion-detection accuracy by 30% over baseline heuristic models.",
      "Implemented YOLOv5/YOLOv8 vehicle detection models for real-time traffic density estimation, achieving 87% accuracy identifying multi-class vehicles from raw video feeds.",
      "Applied feature engineering to forecast congestion spikes, and optimized preprocessing pipelines to reduce model training duration by 22% with zero accuracy trade-off.",
      "Collaborated across a distributed engineering team adhering to agile sprints and reproducible experiment tracking."
    ]
  }
];

export const EDUCATION: EducationItem[] = [
  {
    degree: "B.Tech in Computer Science Engineering (Artificial Intelligence & Machine Learning)",
    institution: "University of Petroleum and Energy Studies (UPES), Dehradun",
    period: "2021 – 2025",
    grade: "CGPA: 7.33 / 10 (73.3%) | Final Sem SGPA: 7.89",
    notes: "Core Focus: Advanced Database Management Systems, Machine Learning, Statistical Analysis, Cloud Containerization, Pattern Recognition."
  },
  {
    degree: "MBA (Master of Business Administration) — Pursuing",
    institution: "Manipal University Jaipur",
    period: "Expected 2028",
    notes: "Enhancing analytical rigor with corporate finance, operations strategy, and executive decision-making frameworks."
  },
  {
    degree: "Senior Secondary (Class XII CBSE)",
    institution: "Delhi Public School, Roorkee",
    period: "2021",
    grade: "75.8%"
  }
];

export const CERTIFICATIONS = [
  {
    title: "Microsoft Certified: Azure AI Engineer Associate (AI-102)",
    issuer: "Microsoft",
    date: "Scheduled / Active May 2025",
    badge: "Cloud AI Credential",
    description: "Validates proficiency in deploying cognitive services, NLP models, computer vision pipelines, and knowledge mining on Microsoft Azure."
  }
];
