import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import CaseStudies from './components/CaseStudies';
import InteractiveLabSection from './components/InteractiveLabSection';
import SkillsSection from './components/SkillsSection';
import ExperienceEducation from './components/ExperienceEducation';
import ContactSection from './components/ContactSection';
import Footer from './components/Footer';
import ResumeModal from './components/ResumeModal';

export default function App() {
  const [isResumeModalOpen, setIsResumeModalOpen] = useState(false);
  const [resumeTab, setResumeTab] = useState<'data-analyst' | 'ai-ml' | 'transcript'>('data-analyst');
  const [interactiveLabTab, setInteractiveLabTab] = useState<string>('payment-simulator');

  const handleOpenResume = (tab: 'data-analyst' | 'ai-ml' | 'transcript' = 'data-analyst') => {
    setResumeTab(tab);
    setIsResumeModalOpen(true);
  };

  const handleSelectInteractive = (type: string) => {
    setInteractiveLabTab(type);
    const labElement = document.getElementById('interactive-lab');
    if (labElement) {
      labElement.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-[#0A0E17] text-slate-100 flex flex-col font-sans selection:bg-emerald-500/30 selection:text-emerald-200 antialiased">
      {/* Top Navbar */}
      <Navbar onOpenResume={handleOpenResume} />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* Recruiter 30s Scan Hero */}
        <Hero onOpenResume={handleOpenResume} />

        {/* Deep-Dive Case Studies */}
        <CaseStudies onSelectInteractive={handleSelectInteractive} />

        {/* Live Interactive Analytics & AI Lab */}
        <InteractiveLabSection 
          activeTab={interactiveLabTab} 
          setActiveTab={setInteractiveLabTab} 
        />

        {/* Core Competencies & Skills */}
        <SkillsSection />

        {/* Professional Experience & Education */}
        <ExperienceEducation onOpenResume={handleOpenResume} />

        {/* Contact & Recruiter Connect */}
        <ContactSection />
      </main>

      {/* Footer */}
      <Footer />

      {/* Verified Resume & Credentials Modal */}
      <ResumeModal
        isOpen={isResumeModalOpen}
        onClose={() => setIsResumeModalOpen(false)}
        initialTab={resumeTab}
      />
    </div>
  );
}
